package com.example.cadastroveiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroveiculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroveiculosApplication.class, args);
	}

}
